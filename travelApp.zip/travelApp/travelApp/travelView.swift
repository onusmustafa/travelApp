import SwiftUI
import SwiftData

struct travelView: View {
    @Environment(\.modelContext) private var context
    @Query(sort:\travel.city) private var travels : [travel]
    @State private var createTravel = false
    var body: some View {
        NavigationStack{
            Group {
                if travels.isEmpty {
                    ContentUnavailableView("Seyehat Bulunamadı.", systemImage: "calendar.badge.plus")
                } else {
                    List{
                        ForEach(travels) { travel in
                            NavigationLink{
                                Text(travel.status.descr)
                                Text(travel.status.iconName)
                                
                            }label: {
                                HStack(spacing:10){
                                    VStack(alignment:.leading){
                                        Text(travel.city)
                                            .font(.title2)
                                        Text(travel.date.formatted(.dateTime.day().month(.wide).year()))
                                        
                                    }
                                }
                            }
                        }
                        .onDelete{ indexSet in
                            indexSet.forEach { index in
                                let travel = travels[index]
                                context.delete(travel)
                            }
                        }
                        
                    }
                    
                    
                }
            }
            .listStyle(.plain)
            .navigationTitle("Seyahatlerim")
            .toolbar{
                Button{
                    createTravel = true
                } label: {
                    Image(systemName: "plus.circle.fill")
                        .imageScale(.large)
                }
            }
            .sheet(isPresented: $createTravel, content: {
                newTravelView()
                    .presentationDetents([.large])    //sheet kısmının büyüklüğünü seçiyoruz.
            })
        }
        
        
    }
}

#Preview {
    travelView()
        .modelContainer(for: travel.self,inMemory: true)
}
