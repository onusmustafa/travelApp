//
//  travel.swift
//  travelApp
//
//  Created by Mustafa Onuş on 31.12.2023.
//

import SwiftUI
import SwiftData

@Model
class travel{
    var city : String
    var date : Date
    var status : Status
    
    init(city: String, date: Date = Date.distantPast, status: Status = .work) {
        self.city = city
        self.date = date
        self.status = status
    }
}

enum Status: Int,Codable,Identifiable,CaseIterable,Hashable {
    case work,cityTour,beach,camp,year,other
    var id: Self{
        self
    }
    var descr: String{
        switch self {
        case .work:
            "İş Seyehati"
        case .cityTour:
            "Şehir Turu"
        case .beach:
            "Plaj Tatili"
        case .camp:
            "Kamp"
        case .year:
            "YılBaşı"
        case .other:
            "Diğer"
        }
    }
    var iconName: String{
        switch self{
        case .work:
            "lsadnflk jasldkfj lksadjflk asjflk jaslkjf lasdfjk"
            
        case .cityTour:
            "sdfaklsjdflj"
        case .beach:
            "osıdfasıudf"
        case .camp:
            "4844848"
        case .year:
            "sdfljksdlfkjasdf"
        case .other:
            "asdjf sjdfasdfjk"
        }
    }
}

