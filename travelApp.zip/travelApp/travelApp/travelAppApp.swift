//
//  travelAppApp.swift
//  travelApp
//
//  Created by Mustafa Onuş on 27.12.2023.
//

import SwiftUI
import SwiftData

@main
struct travelAppApp: App {
    var body: some Scene {
        WindowGroup {
            travelView()
        }
        .modelContainer(for: travel.self)
    }
    init(){
        print(URL.applicationSupportDirectory.path(percentEncoded: false))
    }
}
