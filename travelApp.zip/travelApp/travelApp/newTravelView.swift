//
//  newTravelView.swift
//  travelApp
//
//  Created by Mustafa Onuş on 31.12.2023.
//

import SwiftUI

struct newTravelView: View {
    
    private let sampleTrips = [ "kamp","seyahat","yilbasi","plaj","dog"]
    private let textWork = [ "kamp","seyahat","yilbasi","plaj","dog"]
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) var dismiss
    @State private var city = ""
    @State private var date = Date()
    let dateFormatter = DateFormatter()
    var body: some View {
        NavigationStack{
            VStack{
                Form{
                    TextField("Şehir Giriniz", text: $city)
                    DatePicker(
                        "Seyahat Tarihi",
                        selection: $date,
                        displayedComponents: [.date]
                    )
                    .datePickerStyle(.graphical)
                    .environment(\.locale, Locale.init(identifier: "tr")) //Takvim dil değiştirme
                    .navigationTitle("Seyahat Ekle")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar{
                        ToolbarItem(placement: .topBarLeading) {
                            Button("İptal"){
                                dismiss()
                                
                            }
                            .foregroundColor(.red)
                        }
                    }
                }
            }
            Spacer()
            Text("Plan Seçiniz")
                .font(.headline)
            ScrollView(.horizontal, showsIndicators: true) {
                VStack {
                    HStack(spacing:0) {
                        ForEach(sampleTrips, id: \.self) { trip in
                            HStack {
                                Image(trip)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width:170, height: 120)
                                    .clipShape(RoundedRectangle(cornerRadius: 15))
                                    .padding(.horizontal, 20)
                                    .shadow(radius: 10)
                                    .scrollTransition(.animated, axis: .horizontal) { content, phase in
                                        content
                                            .opacity(phase.isIdentity ? 1.0 : 0.8)
                                            .scaleEffect(phase.isIdentity ? 1.0 : 0.8)
                                    }
                                
                            }
                        }
                        
                        
                    }
                }
            }
            
            .padding()
        }
        Button("Seyahat Oluştur"){
            let travel = travel(city: city, date: date)
            context.insert(travel)   //Yeni Seyehat Ekleme
            dismiss()
        }
        .frame(maxWidth: .infinity,alignment: .center)
        .buttonStyle(.borderedProminent)
        .padding(.vertical)
        .disabled(city.isEmpty) // şehir girilmemiş ise buton pasit
    }
}
#Preview {
    newTravelView()
}
